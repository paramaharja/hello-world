<?php

    if ( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly

    ///////////EDIT BELOW THIS////////////////////////////////////////

    // Names of the required templates
    $t['users_tpl'] = '';
    $t['login_tpl'] = '';
    $t['lost_password_tpl'] = '';
    $t['registration_tpl'] = '';
